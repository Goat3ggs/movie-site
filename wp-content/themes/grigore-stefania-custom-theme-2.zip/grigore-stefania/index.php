<?php get_header() ?>

<?php get_sidebar() ?>

<?php
if (have_posts()) { ?>
    <div class="row">
        <?php while (have_posts()) { ?>
            <div class="col-12 col-lg-12 col-xl-6 mt-3 me-1 post-box">
                <?php the_post(); ?>
                <?php
                get_template_part('/template-parts/post/content', 'excerp'); ?>
            </div>
        <?php } // end while
        ?>
    </div>
    <div class="pagination"><?php the_posts_pagination(); ?></div>
<?php } // end if
?>
<?php get_footer() ?>