<?php
if (is_active_sidebar('footer-widgets')) : ?>
    <div class="container mb-5">
        <div class="row footer-widgets">
            <div class="col-md-4 mt-2">
                <?php dynamic_sidebar('footer-widgets'); ?>
            </div>
        </div>
    </div>
<?php endif; ?>