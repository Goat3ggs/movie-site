<?php get_footer(); ?>
<div class="footer">
    <?php echo get_bloginfo('name') . ' ' . get_the_time('Y')  . ' ' . '<p>Copyright, all right reserved</p>' ?>
</div>