<?php
if (! function_exists('theme_setup')) {
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which runs
     * before the init hook. The init hook is too late for some features, such as indicating
     * support post thumbnails.
     */
    function theme_setup()
    {

        /**
         * Make theme available for translation.
         * Translations can be placed in the /languages/ directory.
         */
        load_theme_textdomain('text_domain', get_template_directory() . '/languages');

        /**
         * Add default posts and comments RSS feed links to <head>.
         */
        add_theme_support('automatic-feed-links');

        /**
         * Enable support for post thumbnails and featured images.
         */
        add_theme_support('post-thumbnails');

        /**
         * Enable the use of a custom logo in your theme.
         */
        add_theme_support('custom-logo');

        $defaults = array(
            'height'               => 100,
            'width'                => 400,
            'flex-height'          => true,
            'flex-width'           => true,
            'header-text'          => array('site-title', 'site-description'),
            'unlink-homepage-logo' => true,
        );
        add_theme_support('custom-logo', $defaults);

        /**
         * Register Custom Navigation Walker
         */
        require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

        /**
         * Add support for two custom navigation menus.
         */
        register_nav_menus(array(
            'primary'   => __('Primary Menu', 'text_domain'),
            'secondary' => __('Secondary Menu', 'text_domain')
        ));

        /**
         * Register Custom Sidebar
         */
        register_sidebar(array(
            'name'          => 'Footer Widgets',
            'id'            => 'footer-widgets',
            'before_widget' => '<div class="footer-widget">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="footer-widget-title">',
            'after_title'   => '</h3>',
        ));

        /**
         * Enable support for the following post formats:
         * aside, gallery, quote, image, and video
         */
        add_theme_support('post-formats', array('aside', 'gallery', 'quote', 'image', 'video'));

        /**
         * Add Bootsatap stylesheet file
         */
        wp_enqueue_style('bootstrap', get_template_directory_uri() . '/modules/css/bootstrap.min.css');

        /**
         * Add main stylesheet file
         */
        wp_enqueue_style('style', get_template_directory_uri() . '/style.css');

        /**
         * Add javascript file
         */
        wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/modules/js/bootstrap.min.js');
    }
} // theme_setup
add_action('after_setup_theme', 'theme_setup');

function custom_excerpt_length($length)
{
    return 30;
}
add_filter('excerpt_length', 'custom_excerpt_length', 999);
