</div>

<div class="container footer-container">
    <div class="row">

        <?php
        get_template_part('/template-parts/footer/site', 'info');
        wp_footer();
        ?>

        <?php
        get_template_part('/template-parts/footer/footer', 'widgets');
        ?>

    </div>

</div>


</body>

</html>